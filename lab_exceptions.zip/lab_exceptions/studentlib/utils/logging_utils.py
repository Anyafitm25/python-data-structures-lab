"""Простий журнал подій та власний контекстний менеджер."""
from types import TracebackType
from typing import Optional


def log_error(exc: BaseException) -> None:
    """Записує інформацію про виключення в консоль.

    Args:
        exc: Виключення, яке потрібно залогувати.
    """
    print(f"   [LOG] {type(exc).__name__}: {exc}")


class ManagedResource:
    """Власний контекстний менеджер, що імітує роботу з ресурсом.

    Замінює явну конструкцію ``try/finally``: метод ``__exit__`` викликається
    завжди, навіть якщо в блоці ``with`` виникло виключення.

    Attributes:
        name: Назва ресурсу.
        is_open: Чи відкритий ресурс зараз.
    """

    def __init__(self, name: str) -> None:
        """Створює менеджер ресурсу.

        Args:
            name: Назва ресурсу.
        """
        self.name = name
        self.is_open = False

    def __enter__(self) -> "ManagedResource":
        self.is_open = True
        print(f"   ресурс '{self.name}' відкрито")
        return self

    def __exit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc: Optional[BaseException],
        tb: Optional[TracebackType],
    ) -> bool:
        self.is_open = False
        print(f"   ресурс '{self.name}' закрито (is_open={self.is_open})")
        return False  # виключення не пригнічується
