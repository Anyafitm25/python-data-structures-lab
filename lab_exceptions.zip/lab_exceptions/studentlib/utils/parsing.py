"""Допоміжні функції розбору числових даних із рядків."""


def parse_grade(text: str) -> int:
    """Перетворює рядок на цілу оцінку.

    Args:
        text: Рядок із числом, наприклад ``"85"``.

    Returns:
        Оцінка як ціле число.

    Raises:
        ValueError: Якщо рядок не є цілим числом.
    """
    return int(text)


def average_of(values: list[str], divisor: int) -> float:
    """Обчислює суму оцінок-рядків, поділену на ``divisor``.

    Args:
        values: Список рядків із числами.
        divisor: Дільник (зазвичай кількість оцінок).

    Returns:
        Результат ділення суми на дільник.

    Raises:
        ValueError: Якщо один з рядків не є цілим числом.
        ZeroDivisionError: Якщо ``divisor`` дорівнює нулю.
    """
    return sum(int(v) for v in values) / divisor
