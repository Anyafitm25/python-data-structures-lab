"""Точка входу: запуск пакета командою ``python -m studentlib``."""
from .demo import run_all

if __name__ == "__main__":
    print(f"Запуск як програми (__name__ == {__name__!r})")
    run_all()
