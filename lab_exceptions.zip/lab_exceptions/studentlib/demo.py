"""Запуск усіх демонстрацій лабораторної роботи."""
from pathlib import Path

import studentlib.utils.parsing as parsing  # абсолютний імпорт цілого модуля
from studentlib.exceptions import ResourceError  # вибірковий абсолютний імпорт

from .services import error_demos, scenarios  # відносний імпорт

DATA = Path(__file__).resolve().parent.parent / "data"


def show_introspection() -> None:
    """Демонструє інтроспекцію: ``__doc__``, ``__name__``, ``__annotations__``, ``help()``."""
    func = parsing.parse_grade
    print(f"   __name__        = {func.__name__}")
    print(f"   __annotations__ = {func.__annotations__}")
    print(f"   __doc__ (початок) = {func.__doc__.strip().splitlines()[0]}")
    print(f"   ResourceError.__doc__ = {ResourceError.__doc__.strip().splitlines()[0]}")
    print("   --- help(parse_grade) ---")
    help(func)


def show_all_demo() -> None:
    """Показує, що ``from studentlib import *`` імпортує лише імена з ``__all__``."""
    namespace: dict = {}
    exec("from studentlib import *", namespace)  # лише для демонстрації __all__
    names = sorted(n for n in namespace if not n.startswith("__"))
    print(f"   імпортовано: {names}")
    print(f"   'parse_grade' серед імен: {'parse_grade' in names}")


def run_all() -> None:
    """Послідовно запускає демонстрації завдань 1–4."""
    print("=" * 60 + "\nЗАВДАННЯ 1. Обробка виключень\n" + "=" * 60)
    print(" 1.1 try/except (успіх / помилка):")
    scenarios.scenario_basic("85")
    scenarios.scenario_basic("abc")
    print(" 1.2 try/except/else/finally (успіх / помилка):")
    scenarios.scenario_full(str(DATA / "students_ok.json"))
    scenarios.scenario_full(str(DATA / "missing.json"))
    print(" 1.3 except (ValueError, ZeroDivisionError) (успіх / 2 помилки):")
    scenarios.scenario_multi(["90", "80", "70"], 3)
    scenarios.scenario_multi(["90", "x"], 2)
    scenarios.scenario_multi(["90", "80"], 0)
    print(" 1.4 контекстний менеджер with (успіх / помилка):")
    scenarios.scenario_context(False)
    scenarios.scenario_context(True)
    print(" 1.5 ExceptionGroup та except* (необов'язково):")
    scenarios.scenario_exception_group({"name": "Анна", "group": "КН-21", "grades": [90]})
    scenarios.scenario_exception_group({"name": "", "group": 21, "grades": [90, 150, "A"]})

    print("\n" + "=" * 60 + "\nЗАВДАННЯ 2. Власні виключення\n" + "=" * 60)
    error_demos.demo_specific_and_base()
    print(" 2.3 Ланцюжок виключень (raise ... from ...):")
    error_demos.demo_chain(str(DATA / "missing.json"))
    error_demos.demo_chain(str(DATA / "students_broken.json"))
    print(" 2.4 Повторне піднесення (raise):")
    error_demos.demo_reraise(str(DATA / "missing.json"))
    print(" 2.5 to_dict():")
    error_demos.demo_to_dict()

    print("\n" + "=" * 60 + "\nЗАВДАННЯ 3. Пакети та __all__\n" + "=" * 60)
    print(f"   __name__ модуля demo при запуску через python -m: {__name__}")
    show_all_demo()

    print("\n" + "=" * 60 + "\nЗАВДАННЯ 4. Документування та інтроспекція\n" + "=" * 60)
    show_introspection()
