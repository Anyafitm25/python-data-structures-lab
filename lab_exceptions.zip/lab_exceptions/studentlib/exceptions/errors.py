"""Ієрархія доменних виключень застосунку.

Структура ієрархії::

    Exception
    └── StudentLibError          (базовий клас застосунку)
        ├── ValidationError      (некоректні дані: поле, значення)
        ├── ResourceError        (проблеми з доступом до ресурсу)
        └── BusinessRuleError    (порушення бізнес-логіки: код помилки)
"""
from typing import Any


class StudentLibError(Exception):
    """Базовий клас усіх виключень застосунку.

    Attributes:
        message: Текстовий опис помилки.
    """

    def __init__(self, message: str) -> None:
        """Створює виключення.

        Args:
            message: Текстовий опис помилки.
        """
        super().__init__(message)
        self.message = message

    def __str__(self) -> str:
        return self.message

    def to_dict(self) -> dict[str, Any]:
        """Перетворює виключення на словник (для логів або передачі мережею).

        Returns:
            Словник з типом і повідомленням помилки.
        """
        return {"type": type(self).__name__, "message": self.message}


class ValidationError(StudentLibError):
    """Помилка валідації вхідних даних.

    Attributes:
        field: Ім'я поля, яке не пройшло перевірку.
        value: Некоректне значення.
        reason: Причина відхилення.
    """

    def __init__(self, field: str, value: Any, reason: str) -> None:
        """Створює помилку валідації.

        Args:
            field: Ім'я поля.
            value: Некоректне значення.
            reason: Причина відхилення.
        """
        super().__init__(reason)
        self.field = field
        self.value = value
        self.reason = reason

    def __str__(self) -> str:
        return f"[VALIDATION] поле '{self.field}': {self.reason} (значення: {self.value!r})"

    def to_dict(self) -> dict[str, Any]:
        """Повертає словник з додатковими полями ``field`` і ``value``."""
        data = super().to_dict()
        data.update({"field": self.field, "value": repr(self.value)})
        return data


class ResourceError(StudentLibError):
    """Помилка доступу до зовнішнього ресурсу (файлу тощо).

    Attributes:
        resource: Ідентифікатор ресурсу (шлях до файлу).
    """

    def __init__(self, resource: str, reason: str) -> None:
        """Створює помилку ресурсу.

        Args:
            resource: Ідентифікатор ресурсу.
            reason: Причина недоступності.
        """
        super().__init__(reason)
        self.resource = resource

    def __str__(self) -> str:
        return f"[RESOURCE] '{self.resource}': {self.message}"

    def to_dict(self) -> dict[str, Any]:
        """Повертає словник з додатковим полем ``resource``."""
        data = super().to_dict()
        data["resource"] = self.resource
        return data


class BusinessRuleError(StudentLibError):
    """Порушення бізнес-правила.

    Attributes:
        code: Код помилки (наприклад, ``LOW_AVERAGE``).
    """

    def __init__(self, code: str, message: str) -> None:
        """Створює помилку бізнес-логіки.

        Args:
            code: Код помилки.
            message: Опис порушеного правила.
        """
        super().__init__(message)
        self.code = code

    def __str__(self) -> str:
        return f"[BUSINESS:{self.code}] {self.message}"

    def to_dict(self) -> dict[str, Any]:
        """Повертає словник з додатковим полем ``code``."""
        data = super().to_dict()
        data["code"] = self.code
        return data
