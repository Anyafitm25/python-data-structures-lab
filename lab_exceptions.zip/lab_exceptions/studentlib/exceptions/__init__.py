"""Підпакет з доменними виключеннями."""
from .errors import BusinessRuleError, ResourceError, StudentLibError, ValidationError

__all__ = ["StudentLibError", "ValidationError", "ResourceError", "BusinessRuleError"]
