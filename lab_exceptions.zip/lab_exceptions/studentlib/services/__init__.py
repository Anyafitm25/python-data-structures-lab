"""Підпакет з бізнес-логікою та сценаріями."""
from .loader import load_students
from .rules import check_scholarship
from .validators import validate_student

__all__ = ["load_students", "validate_student", "check_scholarship"]
