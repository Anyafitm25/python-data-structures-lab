"""Сценарії обробки виключень (завдання 1): try/except/else/finally, кортеж типів, with."""
from ..exceptions import ValidationError
from ..utils.logging_utils import ManagedResource
from ..utils.parsing import average_of, parse_grade
from .validators import validate_student_all


def scenario_basic(text: str) -> None:
    """Сценарій 1: базовий try/except (очікується ValueError від int())."""
    try:
        grade = parse_grade(text)
        print(f"   успіх: оцінка = {grade}")
    except ValueError:
        print(f"   помилка: '{text}' не є цілим числом")


def scenario_full(path: str) -> None:
    """Сценарій 2: повна конструкція try/except/else/finally.

    ``else`` виконується лише без виключення; ``finally`` — завжди.
    """
    file = None
    try:
        file = open(path, encoding="utf-8")
        content = file.read()
    except FileNotFoundError:
        print(f"   помилка: файл '{path}' не знайдено")
    else:
        print(f"   else: файл прочитано, {len(content)} символів")
    finally:
        print("   finally: звільняємо ресурси")
        if file is not None:
            file.close()


def scenario_multi(values: list[str], divisor: int) -> None:
    """Сценарій 3: кілька типів виключень в одному except."""
    try:
        result = average_of(values, divisor)
        print(f"   успіх: результат = {result:.2f}")
    except (ValueError, ZeroDivisionError) as exc:
        print(f"   помилка ({type(exc).__name__}): {exc}")


def scenario_context(fail: bool) -> None:
    """Сценарій 4: контекстний менеджер замість try/finally."""
    try:
        with ManagedResource("база даних") as res:
            print(f"   робота з ресурсом '{res.name}'")
            if fail:
                raise RuntimeError("збій під час роботи")
    except RuntimeError as exc:
        print(f"   перехоплено поза with: {exc}")


def scenario_exception_group(record: dict) -> None:
    """Необов'язкове: ExceptionGroup та except* для кількох полів одразу."""
    try:
        validate_student_all(record)
        print("   успіх: запис коректний")
    except* ValidationError as group:
        for err in group.exceptions:
            print(f"   {err}")
