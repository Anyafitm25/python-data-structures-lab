"""Валідація записів про студентів."""
from typing import Any

from ..exceptions import ValidationError


def validate_grade(value: Any) -> int:
    """Перевіряє, що оцінка є цілим числом від 0 до 100.

    Args:
        value: Значення оцінки.

    Returns:
        Те саме значення, якщо воно коректне.

    Raises:
        ValidationError: Якщо значення не ціле число або поза діапазоном 0..100.
    """
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValidationError("grade", value, "оцінка має бути цілим числом")
    if not 0 <= value <= 100:
        raise ValidationError("grade", value, "оцінка має бути в діапазоні 0..100")
    return value


def validate_student(record: dict[str, Any]) -> dict[str, Any]:
    """Перевіряє запис про студента; зупиняється на першій помилці.

    Args:
        record: Словник з ключами ``name``, ``group``, ``grades``.

    Returns:
        Той самий запис, якщо він коректний.

    Raises:
        ValidationError: Якщо будь-яке поле некоректне.
    """
    name = record.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ValidationError("name", name, "ім'я має бути непорожнім рядком")
    group = record.get("group")
    if not isinstance(group, str):
        raise ValidationError("group", group, "група має бути рядком")
    for grade in record.get("grades", []):
        validate_grade(grade)
    return record


def validate_student_all(record: dict[str, Any]) -> None:
    """Перевіряє всі поля й збирає усі помилки в ``ExceptionGroup``.

    Args:
        record: Словник з ключами ``name``, ``group``, ``grades``.

    Raises:
        ExceptionGroup: Група з ``ValidationError`` для кожного некоректного поля.
    """
    errors: list[Exception] = []
    name = record.get("name")
    if not isinstance(name, str) or not name.strip():
        errors.append(ValidationError("name", name, "ім'я має бути непорожнім рядком"))
    group = record.get("group")
    if not isinstance(group, str):
        errors.append(ValidationError("group", group, "група має бути рядком"))
    for grade in record.get("grades", []):
        try:
            validate_grade(grade)
        except ValidationError as exc:
            errors.append(exc)
    if errors:
        raise ExceptionGroup("Запис не пройшов валідацію", errors)
