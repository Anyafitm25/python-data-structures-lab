"""Бізнес-правила застосунку."""
from ..exceptions import BusinessRuleError

MIN_SCHOLARSHIP_AVERAGE = 75.0


def check_scholarship(average: float) -> str:
    """Перевіряє право на стипендію за середнім балом.

    Args:
        average: Середній бал студента.

    Returns:
        Рядок із рішенням, якщо правило виконано.

    Raises:
        BusinessRuleError: Якщо середній бал нижчий за мінімальний (код ``LOW_AVERAGE``).
    """
    if average < MIN_SCHOLARSHIP_AVERAGE:
        raise BusinessRuleError(
            "LOW_AVERAGE",
            f"середній бал {average:.1f} нижчий за {MIN_SCHOLARSHIP_AVERAGE}",
        )
    return f"стипендію призначено (середній бал {average:.1f})"
