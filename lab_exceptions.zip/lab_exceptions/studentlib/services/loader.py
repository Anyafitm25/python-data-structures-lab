"""Завантаження даних про студентів з JSON-файлів."""
import json
from typing import Any

from ..exceptions import ResourceError


def load_students(path: str) -> list[dict[str, Any]]:
    """Читає список студентів із JSON-файлу.

    Args:
        path: Шлях до JSON-файлу.

    Returns:
        Список записів про студентів.

    Raises:
        ResourceError: Якщо файл не знайдено або він містить некоректний JSON.
            Оригінальна помилка доступна через ``__cause__``.
    """
    try:
        with open(path, encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError as exc:
        raise ResourceError(path, "файл не знайдено") from exc
    except json.JSONDecodeError as exc:
        raise ResourceError(path, "некоректний формат JSON") from exc
