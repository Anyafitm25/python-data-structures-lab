"""Сценарії власних виключень (завдання 2): raise, ланцюжки, повторне піднесення."""
from ..exceptions import (
    BusinessRuleError,
    ResourceError,
    StudentLibError,
    ValidationError,
)
from ..utils.logging_utils import log_error
from .loader import load_students
from .rules import check_scholarship
from .validators import validate_student


def demo_specific_and_base() -> None:
    """Перехоплення конкретного виключення та всієї категорії через базовий клас."""
    print(" 2.1 Конкретні виключення:")
    cases = [
        lambda: validate_student({"name": "", "group": "КН-21", "grades": []}),
        lambda: load_students("data/missing.json"),
        lambda: check_scholarship(60.0),
    ]
    for case in cases:
        try:
            case()
        except ValidationError as exc:
            print(f"   ValidationError -> {exc}")
        except ResourceError as exc:
            print(f"   ResourceError   -> {exc}")
        except BusinessRuleError as exc:
            print(f"   BusinessRuleError -> {exc}")

    print(" 2.2 Уся категорія через базовий клас StudentLibError:")
    for case in cases:
        try:
            case()
        except StudentLibError as exc:
            print(f"   {type(exc).__name__} (батьки: "
                  f"{[c.__name__ for c in type(exc).__mro__[1:3]]})")


def demo_chain(path: str) -> None:
    """Ланцюжок виключень: доступ до ``__cause__``."""
    try:
        load_students(path)
    except ResourceError as exc:
        print(f"   доменна помилка: {exc}")
        print(f"   __cause__: {type(exc.__cause__).__name__}: {exc.__cause__}")


def demo_reraise(path: str) -> None:
    """Повторне піднесення: логуємо та передаємо виключення далі."""
    try:
        try:
            load_students(path)
        except ResourceError as exc:
            log_error(exc)  # побічна дія
            raise  # повторне піднесення без аргументів
    except ResourceError as exc:
        print(f"   зовнішній рівень отримав ту саму помилку: {exc.resource}")


def demo_to_dict() -> None:
    """Серіалізація виключення в словник."""
    try:
        validate_student({"name": "Анна", "group": 5, "grades": []})
    except ValidationError as exc:
        print(f"   {exc.to_dict()}")
