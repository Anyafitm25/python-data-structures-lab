"""Пакет studentlib: завантаження та валідація даних про студентів.

Експортує лише ключові імена; решта доступна через підпакети.
"""
from .exceptions import BusinessRuleError, ResourceError, StudentLibError, ValidationError
from .services import check_scholarship, load_students, validate_student

__all__ = [
    "StudentLibError",
    "ValidationError",
    "ResourceError",
    "BusinessRuleError",
    "load_students",
    "validate_student",
    "check_scholarship",
]
